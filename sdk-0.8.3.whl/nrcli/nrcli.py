import click
import netrise
import sys
import csv
import json
import os
import re
import time
import requests
import pkg_resources
import importlib.metadata
from gql import gql
from fnmatch import fnmatch
from .nrdiff import print_diff
from .downloads import download_asset, download_extracted_asset


def flatten_json(json):
    """Flattens a JSON string into a single layer."""

    new_json = {}
    for i in json.keys():
        if isinstance(json[i], dict):
            d = flatten_json(json[i])
            for j in d.keys():
                new_json[i + "/" + j] = d[j]
        else:
            new_json[i] = json[i]

    return new_json


def json_to_csv(json):
    """Converts JSON into a CSV string."""

    if isinstance(json, dict):
        json = [json]

    columns = list(flatten_json(json[0]).keys())

    csv = ""
    for c in columns:
        csv += c + ","
    csv = csv[:-1] + "\n"

    for j in json:
        flat = flatten_json(j)
        for k in flat.keys():
            csv += str(flat[k]) + ","
        csv = csv[:-1] + "\n"

    return csv


def csv_to_gql_input(csv):
    """Converts a CSV string into the input of a GQL query."""

    out = ""

    elements = csv.split(",")
    for element in elements:
        sub_elements = element.split("/")
        for se in range(0, len(sub_elements)):
            if se == len(sub_elements) - 1:
                out += sub_elements[se] + " "
            else:
                out += sub_elements[se] + " { "

        for i in range(0, len(sub_elements) - 1):
            out += "} "

    return out


@click.pass_context
def init(ctx, cfg_path):
    """Create NetRise client and store it in the click context object."""

    try:
        client = netrise.API.from_config_file(cfg_path)
        ctx.obj = client

    except ConnectionError:
        click.echo(
            "Failed to establish a connection with the NetRise API. Check your internet connection."
        )
        sys.exit()

    except FileNotFoundError:
        click.echo(f"Config file '{cfg_path}' does not exist.")
        sys.exit()


@click.group()
@click.option(
    "--config",
    default="./config.yaml",
    help="Path to the configuration file.",
)
@click.version_option(
    version=importlib.metadata.version("netrise"),
    message="NetRise Python SDK %(version)s",
)
def cli(config):
    init(config)


@cli.command()
@click.argument("id")
@click.option(
    "--watch",
    "-w",
    is_flag=True,
    help="If an analysis job is ongoing, keep watching it until its status changes.",
)
@click.pass_obj
def status(client, id, watch):
    """Checks the status of an ongoing or finished analysis job."""

    response = client.status(id)

    # if watch flag is set, check firmware every minute to see if its finished processing or not,
    # and when it finally does finish, output the final result.
    if watch:
        click.echo(f"Watching '{id}' ...")
    while watch:
        if response == netrise.Status.INPROGRESS:
            time.sleep(60)
            response = client.status(id)
        else:
            click.echo("Finished processing! Status:")
            break

    click.echo(str(response).removeprefix("Status."))


@cli.command()
@click.argument("path", type=click.Path(exists=True))
@click.option("--name", default="")
@click.option("--vendor", default="")
@click.option("--product", default="")
@click.option("--version", default="")
@click.option(
    "--asset-group",
    default="",
    help="The asset group ID to add this asset to."
)
@click.option(
    "--upload-id",
    "-u",
    is_flag=True,
    help="\b\nReturn the Upload ID of an image instead of its Asset ID. (May be faster.)",
)
@click.pass_obj
def submit(client, path, name, vendor, product, version, asset_group, upload_id) -> str:
    """Submits a firmware image with the given metadata.

    Returns the asset's ID on submission."""

    click.echo(f"Uploading '{path}' ...")

    args = netrise.SubmitInput(
        name=name,
        manufacturer=vendor,
        model=product,
        version=version,
        assetGroupIds=[asset_group]
    )

    try:
        id = client.submit(path, args, not upload_id)
        click.echo(f"Uploaded '{path}': {id}")

    except requests.HTTPError as e:
        click.echo("Failed to upload firmware image:")
        click.echo(e)


@cli.command("gql")
@click.argument("input", type=click.File("r"))
@click.argument("output", type=click.File("w"))
@click.option("--arguments", help="JSON string of arguments.")
@click.pass_obj
def gql_raw(client, input, output, arguments):
    """Executes the given raw GQL query.

    Uses the contents of INPUT as a GQL query and dumps the results to OUTPUT.
    --arguments is a JSON dictionary of arguments for the query to use.
    """

    # execute query from contents of INPUT
    query = gql(input.read())

    data = client.execute(query, json.loads(arguments))

    # ouputs contents of result to OUTPUT
    output.write(json.dumps(data, indent=4))


@cli.command()
@click.argument("id")
@click.argument("output", type=click.File("w"))
@click.option(
    "--data",
    "-d",
    default=None,
    help="\b\nRequest specific data in CSV format. \n(e.g. 'name,vendor,version').",
)
@click.pass_obj
def get_asset(client, id, output, data):
    """Outputs data from an asset.

    OUTPUT is a JSON file."""

    if data:
        data = csv_to_gql_input(data)

    default_query_data = """
        assetCpe
        componentId
        createdAt
        endTime
        fileName
        name
        orgId
        product
        risk {
            category
            rawScore
            score
        }
        startTime
        status
        type
        updatedAt
        vendor
        version
    """

    query = gql(
        f"""
        query GetAsset($args: AssetInput) {{
            asset(args: $args) {{
                {default_query_data if not data else data}
            }}
        }}
        """
    )

    image = client.execute(query, {"args": {"assetId": id}})["asset"]

    output.write(json.dumps(image, indent=4))


@cli.command()
@click.pass_obj
@click.argument("output", type=click.File("w"))
@click.option(
    "--data",
    "-d",
    default=None,
    help="\b\nRequest specific data in CSV format. \n(e.g. 'name,vendor,version').",
)
def get_assets(client, output, data):
    """Outputs data from all available assets.

    OUTPUT is a JSON file."""

    if data:
        data = csv_to_gql_input(data)

    default_query = f"""
        componentId, createdAt, endTime, fileName, name, orgId,
        product, risk {{ category, score, rawScore }}, startTime, status,
        type, updatedAt, vendor, version
    """

    query = gql(
        f"""
        query GetAssets($args: AssetsInput) {{
            assets(args: $args) {{        
                assets {{
                    {default_query if not data else data}
                }}
                pageInfo {{
                    nextPageToken
                    prevPageToken
                    totalSize
                }}
            }}
        }}
    """
    )

    components = []
    params = {"args": {"cursor": {"first": 100, "after": ""}}}
    has_next_page = True

    while has_next_page:
        data = client.execute(query, variable_values=params)["assets"]
        components.extend(data["assets"])

        next_page_token = data["pageInfo"]["nextPageToken"]
        params["args"]["cursor"]["after"] = next_page_token
        has_next_page = next_page_token != ""

    output.write(json.dumps(components, indent=4))


@cli.command()
@click.pass_obj
def token(client):
    """Prints out the client's token."""

    click.echo(client.token)


@cli.command()
@click.pass_obj
def claims(client):
    """Prints out the client's claims."""

    click.echo(client.claims)


@cli.command()
@click.pass_obj
@click.argument("id_a")
@click.argument("id_b")
@click.option(
    "--out",
    "-o",
    type=click.File("w"),
    default=None,
    help="Output diff to a JSON file.",
)
def diff(client, id_a, id_b, out):
    """Gets the difference between two images."""

    print_diff(client, id_a, id_b, out)


@cli.command()
@click.pass_obj
@click.argument(
    "type", type=click.Choice(["sbom", "asset", "extracted-asset"])
)
@click.argument("id")
@click.argument("output", type=click.File("wb"))
def download(client, type, id, output):
    """Download an asset, extracted asset, or an asset's SBOM."""

    if type == "sbom":
        output.write(
            client.download_sbom(
                id, "CDX_JSON", "", False, False, False, False
            ).encode("utf-8")
        )
        click.echo(f"SBOM downloaded.")

    elif type == "asset":
        output.write(download_asset(client, id))
        click.echo(f"Asset downloaded.")

    elif type == "extracted-asset":
        output.write(download_extracted_asset(client, id))
        click.echo(f"Extracted asset downloaded.")


@cli.command()
@click.pass_obj
@click.option("--vendor")
@click.option("--product")
@click.option("--version")
@click.option("--name")
@click.option(
    "--regex", "-r", is_flag=True, help="Use regex instead of fnmatch."
)
@click.option("--ignore-case", "-i", is_flag=True, help="Ignore casing.")
@click.option(
    "--verbose",
    "-v",
    is_flag=True,
    help="List all metadata from matching firmware instead of just their IDs.",
)
@click.option(
    "--out", "-o", help="Output to specified JSON file.", type=click.File("w")
)
def search(
    client, vendor, product, version, name, regex, ignore_case, verbose, out
):
    """Search NetRise for a specific firmware.

    Uses python's 'fnmatch' by default.
    (https://docs.python.org/3/library/fnmatch.html)
    """

    # set defaults to match-all strings
    default = "*"
    if regex:
        default = ".*"
    if not vendor:
        vendor = default
    if not product:
        product = default
    if not version:
        version = default
    if not name:
        name = default

    if ignore_case:
        vendor = vendor.lower()
        product = product.lower()
        version = version.lower()
        name = name.lower()

    list_query = gql(
        """
        query ListAssets($args: AssetsInput) {
            assets(args: $args) {
                assets {
                    componentId
                    name
                    product
                    version
                    vendor
                }
                pageInfo {
                    nextPageToken
                    prevPageToken
                    totalSize
                }
            }
        }
        """
    )

    # page through and collect all assets in the org
    assets = []
    params = {"args": {"cursor": {"first": 100}}}
    has_next_page = True

    while has_next_page:
        data = client.execute(list_query, params)["assets"]
        assets.extend(data["assets"])

        page_info = data["pageInfo"]
        has_next_page = page_info["nextPageToken"] != ""
        params["args"]["cursor"]["after"] = page_info["nextPageToken"]

    # check each asset for matches, and put them in the matches array
    matches = []
    for asset in assets:

        vend = asset["vendor"]
        prod = asset["product"]
        ver = asset["version"]
        nam = asset["name"]
        id = asset["componentId"]

        if ignore_case:
            vend = vend.lower()
            prod = prod.lower()
            ver = ver.lower()
            nam = nam.lower()

        if regex:
            if (
                re.search(vendor, vend)
                and re.search(product, prod)
                and re.search(version, ver)
                and re.search(name, nam)
            ):
                matches.append(asset)
        else:
            if (
                fnmatch(vend, vendor)
                and fnmatch(prod, product)
                and fnmatch(ver, version)
                and fnmatch(nam, name)
            ):
                matches.append(asset)

    # output results, either to file or to console output
    if out:
        out.write(json.dumps(matches, indent=4))
        click.echo(f"Wrote matches to '{out.name}'.")
    else:
        if matches != []:
            click.echo(f"Matching firmware found! (count: {len(matches)})")
            for match in matches:
                if verbose:
                    click.echo(
                        f"{match['componentId']} - name: {match['name']}, vendor: {match['vendor']}, product: {match['product']}, version: {match['version']}"
                    )
                else:
                    click.echo(match["componentId"])
        else:
            click.echo(f"No matches found.")


@cli.command()
@click.pass_obj
@click.argument("id")
@click.option("--name")
@click.option("--product")
@click.option("--vendor")
@click.option("--version")
def update(client, id, name, product, vendor, version):
    """Update the metadata of a firmware image."""

    update_query = gql(
        """
        mutation UpdateFirmware($args: UpdateAssetInput) {
            asset {
                update(args: $args) { componentId }
            }
        }
        """
    )

    client.execute(
        update_query,
        {
            "args": {
                "id": id,
                "name": name,
                "product": product,
                "vendor": vendor,
                "version": version,
            }
        },
    )
    click.echo("Updated metadata of image.")


@cli.group()
@click.pass_obj
def asset_group(client):
    """Manage asset groups."""

@asset_group.command("get-id")
@click.pass_obj
@click.argument("name")
def asset_group_get_id(client, name):
    """Get the ID of an asset group from its name."""

    id = client.get_asset_group_id(name)
    if id:
        click.echo(id)
    else:
        click.echo("No asset group found with that name.")

@asset_group.command("create")
@click.pass_obj
@click.argument("name")
@click.argument("description")
@click.argument("asset_ids", nargs=-1)
def asset_group_create(client, name, description, asset_ids):
    """Create an asset group."""

    id = client.create_asset_group(name, description, asset_ids)
    click.echo(f"Created asset group with ID: {id}")

@asset_group.command("delete")
@click.pass_obj
@click.argument("id")
def asset_group_delete(client, id):
    """Delete an asset group."""

    success = client.delete_asset_group(id)
    if success:
        click.echo("Successfully deleted asset group.")
    else:
        click.echo("Failed to delete asset group.")

@asset_group.command("add-assets")
@click.pass_obj
@click.argument("group_id")
@click.argument("asset_ids", nargs=-1, required=True)
def asset_group_add_assets(client, group_id, asset_ids):
    """Add assets to an asset group."""

    success = client.add_assets_to_group(group_id, list(asset_ids))
    if success:
        click.echo("Succesfully added assets to group.")
    else:
        click.echo("Failed to add assets to group.")

@asset_group.command("remove-assets")
@click.pass_obj
@click.argument("group_id")
@click.argument("asset_ids", nargs=-1, required=True)
def asset_group_remove_assets(client, group_id, asset_ids):
    """Remove assets from an asset group."""

    success = client.remove_assets_from_group(group_id, list(asset_ids))
    if success:
        click.echo("Succesfully removed assets from group.")
    else:
        click.echo("Failed to add assets to group.")

@asset_group.command("list-assets")
@click.pass_obj
@click.argument("group_id")
@click.option("--with-id", is_flag=True, help="Include the assets' IDs")
def asset_group_list_assets(client, group_id, with_id):
    """List all assets in an asset group."""

    query = gql(
        """
        query GetAssetsInGroup($args: AssetsRelayInput!) {
            assetsRelay(args: $args) {
                edges {
                    node {
                        name
                        id
                    }
                }
                pageInfo {
                    hasNextPage
                    endCursor
                }
            }
        }
        """
    )
    assets = client.collect(
        query,
        {"args": {
            "groupIds": [group_id]
        }}
    )

    if len(assets) == 0:
        click.echo("No assets in group.")
    else:
        for asset in assets:
            if with_id:
                click.echo(f"{asset['name']}: {asset['id']}")
            else:
                click.echo(asset["name"])

@asset_group.command("list")
@click.pass_obj
def asset_group_list(client):
    """List all asset groups."""

    query = gql(
        """
        query ListAssetGroups($args: AssetGroupsInput!) {
            assetGroups(args: $args) {
                edges {
                    node {
                        name
                        id
                    }
                }
                pageInfo {
                    endCursor
                    hasNextPage
                }
            }
        }
        """
    )
    groups = client.collect(query)
    for group in groups:
        click.echo(f"{group['name']}: {group['id']}")

    if len(groups) == 0:
        click.echo("No asset groups.")

# load all nrcli plugins
plugins = list(pkg_resources.iter_entry_points("nrcli_plugins"))
for p in plugins:
    plugin = p.load()
    plugin(cli)


@cli.command("list-plugins")
def list_plugins():
    """List all loaded plugins."""

    if len(plugins) == 0:
        click.echo("No plugins loaded.")
        quit(0)

    click.echo("Loaded plugins: (%d)" % len(plugins))
    for plugin in plugins:
        click.echo("* " + plugin.name)
