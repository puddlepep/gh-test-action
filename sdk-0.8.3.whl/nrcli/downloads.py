import netrise
from gql import gql
import requests
import time

def finish_download(client: netrise.API, operation_id: str) -> bytes:
    """Returns the data from an initiated download operation."""

    operation_query = gql(
        """
        query get_operation($args: OperationInput) {
            operation(args: $args) {
                done
                error
                signedUrl { url }
            }
        }
        """)

    operation_data = None
    finished_downloading = False
    while not finished_downloading:
        operation_data = client.v3.execute(operation_query, {'args': {'operationId': operation_id}})['operation']
        finished_downloading = operation_data['done']

        if operation_data["error"]:
            raise Exception(operation_data["error"])
        time.sleep(5)
    
    data = requests.get(operation_data["signedUrl"]["url"], verify=client.config.enable_ssl).content
    return data

def download_asset(client: netrise.API, asset_id) -> bytes:
    """Downloads an asset"""

    query = gql(
        """
        query get_asset($args: FirmwareDownloadInput) {
            download {
                firmware(args: $args) {
                    operationId
                }
            }
        }
        """)

    operation_id = client.v3.execute(query, {"args": {"componentId": asset_id}})["download"]["firmware"]["operationId"]
    asset_bytes = finish_download(client, operation_id)
    return asset_bytes

def download_extracted_asset(client: netrise.API, asset_id) -> bytes:
    """Downloads an extracted asset"""

    query = gql(
        """
        query get_extracted_asset($args: ExtractedFirmwareDownloadInput) {
            download {
                extractedFirmware(args: $args) {
                    operationId
                }
            }
        }
        """)
    
    operation_id = client.v3.execute(query, {"args": {"componentId": asset_id}})["download"]["extractedFirmware"]["operationId"]
    extracted_asset_bytes = finish_download(client, operation_id)
    return extracted_asset_bytes
