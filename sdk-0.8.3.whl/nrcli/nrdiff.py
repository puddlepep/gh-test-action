import netrise
import requests
import time
import json
import sys
from gql import gql
from collections import Counter

# returns a list of values from a specified key
def get_values(data, key):
    return [x[key] for x in data]

def get_data(client: netrise.API, asset_id: str) -> dict:
    """ Returns the relevant data of an asset. """
    
    query = gql(
        '''
        query get_component($componentId: ID!) {
            component(componentId: $componentId) {
                id
                score { riskScore { score category } }

                artifact {
                    certificate {
                        coordinate
                        sha256
                        signature_valid
                    }

                    publicKey {
                        id
                        foundPrivateKey
                    }

                    binaryProtection {
                        coordinate
                        relro
                        canary
                        nx
                        pie
                    }
                }

                issue {
                    definition { name }
                    severity
                    status
                }
            }
        }
        '''
    )

    credential_query = gql(
        '''
        query get_credentials($args: CredentialsInput!) {
            credentials(args: $args) {
                user_name
                cracked
            }
        }
        '''
    )

    data = client.execute(query, {'componentId': asset_id})
    data['sbom'] = json.loads(client.download_sbom(asset_id, "CDX_JSON", "", True, True, True, True))
    data['credentials'] = client.execute(credential_query, {'args': {'componentId': asset_id}})['credentials']
    return data


def diff_misconfigurations(data_a: dict, data_b: dict) -> dict:
    a_issues = data_a['component']['issue']
    b_issues = data_b['component']['issue']

    diff = {'a': {}, 'b': {}, 'shared': {}}
    diff['a']['all'] = a_issues
    diff['b']['all'] = b_issues

    diff['a']['failed'] = [x for x in a_issues if x['status'] == 'FAILED']
    diff['b']['failed'] = [x for x in b_issues if x['status'] == 'FAILED']

    a_names = [x['definition']['name'] for x in a_issues]
    b_names = [x['definition']['name'] for x in b_issues]
    diff['a']['unique'] = [x for x in a_issues if x['definition']['name'] not in b_names]
    diff['b']['unique'] = [x for x in b_issues if x['definition']['name'] not in a_names]

    diff['shared']['all'] = [x for x in a_issues if x['definition']['name'] in b_names]
    diff['shared']['failed'] = [x for x in a_issues if x['status'] == 'FAILED' and x in b_issues]
    return diff


def diff_binary_protections(data_a: dict, data_b: dict) -> dict:
    a_bps = data_a['component']['artifact']['binaryProtection']
    b_bps = data_b['component']['artifact']['binaryProtection']

    if a_bps is None:
        a_bps = []

    if b_bps is None:
        b_bps = []

    diff = {'a': {}, 'b': {}, 'shared': {}}
    diff['a']['all'] = a_bps
    diff['b']['all'] = b_bps

    a_binaries = [x['coordinate'] for x in a_bps]
    b_binaries = [x['coordinate'] for x in b_bps]
    diff['a']['unique'] = [x for x in a_bps if x['coordinate'] not in b_binaries]
    diff['b']['unique'] = [x for x in b_bps if x['coordinate'] not in a_binaries]

    diff['a']['enabled'] = 0
    for p in a_bps:
        if p['relro'] != 'false': diff['a']['enabled'] += 1
        if p['canary'] != False: diff['a']['enabled'] += 1
        if p['nx'] != False: diff['a']['enabled'] += 1
        if p['pie'] != 'none': diff['a']['enabled'] += 1

    diff['b']['enabled'] = 0
    for p in b_bps:
        if p['relro'] != 'false': diff['b']['enabled'] += 1
        if p['canary'] != False: diff['b']['enabled'] += 1
        if p['nx'] != False: diff['b']['enabled'] += 1
        if p['pie'] != 'none': diff['b']['enabled'] += 1

    diff['shared']['all'] = [x for x in a_bps if x['coordinate'] in b_binaries]
    return diff


def diff_keys(data_a: dict, data_b: dict) -> dict:
    a_pub_keys = data_a['component']['artifact']['publicKey']
    b_pub_keys = data_b['component']['artifact']['publicKey']

    if a_pub_keys is None:
        a_pub_keys = []

    if b_pub_keys is None:
        b_pub_keys = []

    diff = {'a': {}, 'b': {}, 'shared': {}}
    diff['a']['all'] = a_pub_keys
    diff['b']['all'] = b_pub_keys

    diff['a']['with_private'] = [x for x in a_pub_keys if x['foundPrivateKey']]
    diff['b']['with_private'] = [x for x in b_pub_keys if x['foundPrivateKey']]

    a_ids = [x['id'] for x in a_pub_keys]
    b_ids = [x['id'] for x in b_pub_keys]
    diff['a']['unique'] = [x for x in a_pub_keys if x['id'] not in b_ids]
    diff['b']['unique'] = [x for x in b_pub_keys if x['id'] not in a_ids]

    diff['shared']['all'] = [x for x in a_pub_keys if x['id'] in b_ids]
    diff['shared']['with_private'] = [x for x in a_pub_keys if x['foundPrivateKey'] and x['id'] in b_ids]
    return diff


def diff_certificates(data_a: dict, data_b: dict) -> dict:
    try:
        a_certs = data_a['component']['artifact']['certificate']
        b_certs = data_b['component']['artifact']['certificate']
    except:
        return {}

    if a_certs is None:
        a_certs = []

    if b_certs is None:
        b_certs = []

    diff = {'a': {}, 'b': {}, 'shared': {}}
    diff['a']['all'] = a_certs
    diff['b']['all'] = b_certs

    diff['a']['invalid'] = [x for x in a_certs if not x['signature_valid']]
    diff['b']['invalid'] = [x for x in b_certs if not x['signature_valid']]

    a_hashes = [x['sha256'] for x in a_certs]
    b_hashes = [x['sha256'] for x in b_certs]
    diff['a']['unique'] = [x for x in a_certs if x['sha256'] not in b_hashes]
    diff['b']['unique'] = [x for x in b_certs if x['sha256'] not in a_hashes]

    diff['shared']['all'] = [x for x in a_certs if x['sha256'] in b_hashes]
    diff['shared']['invalid'] = [x for x in b_certs if not x['signature_valid'] and x['sha256'] in a_hashes]
    return diff


def diff_credentials(data_a: dict, data_b: dict) -> dict:
    a_creds = data_a['credentials']
    b_creds = data_b['credentials']

    if a_creds is None:
        a_creds = []

    if b_creds is None:
        b_creds = []

    diff = {'a': {}, 'b': {}, 'shared': {}}
    diff['a']['all'] = a_creds
    diff['b']['all'] = b_creds

    diff['a']['cracked'] = [x for x in a_creds if x['cracked']]
    diff['b']['cracked'] = [x for x in b_creds if x['cracked']]

    a_usernames = [x['user_name'] for x in a_creds]
    b_usernames = [x['user_name'] for x in b_creds]
    diff['a']['unique'] = [x for x in a_creds if x['user_name'] not in b_usernames]
    diff['b']['unique'] = [x for x in b_creds if x['user_name'] not in a_usernames]

    diff['shared']['all'] = [x for x in a_creds if x['user_name'] in b_usernames]
    diff['shared']['cracked'] = [x for x in a_creds if x['cracked'] and x in b_creds]
    return diff


def diff_vulnerabilities(data_a: dict, data_b: dict) -> dict:
    a_ids = [x['id'] for x in data_a['sbom']['vulnerabilities']]
    b_ids = [x['id'] for x in data_b['sbom']['vulnerabilities']]

    diff = {'a': {}, 'b': {}, 'shared': {}}
    diff['a']['all'] = a_ids
    diff['b']['all'] = b_ids

    diff['a']['unique'] = [x for x in a_ids if x not in b_ids]
    diff['b']['unique'] = [x for x in b_ids if x not in a_ids]

    diff['shared']['all'] = [x for x in a_ids if x in b_ids]
    return diff


def diff_components(data_a: dict, data_b: dict) -> dict:
    a_components = [{'name': x['name'], 'version': x.get('version', '')} for x in data_a['sbom']['components'] if x['type'] != 'file']
    b_components = [{'name': x['name'], 'version': x.get('version', '')} for x in data_b['sbom']['components'] if x['type'] != 'file']

    diff = {'a': {}, 'b': {}, 'shared': {}}
    diff['a']['all'] = a_components
    diff['b']['all'] = b_components

    a_names = [x['name'] for x in a_components]
    b_names = [x['name'] for x in b_components]
    diff['a']['unique'] = [x for x in a_components if x['name'] not in b_names]
    diff['b']['unique'] = [x for x in b_components if x['name'] not in a_names]

    diff['shared']['all'] = [x for x in a_components if x['name'] in b_names]
    diff['shared']['matching_version'] = [x for x in a_components if x in b_components]
    return diff


def print_diff(client: netrise.API, asset_id_a: str, asset_id_b: str, output = None):
    """ Gets the difference between two assets. """

    data_a = get_data(client, asset_id_a)
    data_b = get_data(client, asset_id_b)

    try: vuln_diff = diff_vulnerabilities(data_a, data_b)
    except: vuln_diff = {}
    try: comp_diff = diff_components(data_a, data_b)
    except: comp_diff = {}
    try: cred_diff = diff_credentials(data_a, data_b)
    except: cred_diff = {}
    try: cert_diff = diff_certificates(data_a, data_b)
    except: cert_diff = {}
    try: key_diff = diff_keys(data_a, data_b)    
    except: key_diff = {}
    try: bp_diff = diff_binary_protections(data_a, data_b)
    except: bp_diff = {}
    try: misconfig_diff = diff_misconfigurations(data_a, data_b)
    except: misconfig_diff = {}    

    if output:
        all_diffs = {
            'vulnerabilities': vuln_diff,
            'components': comp_diff,
            'credentials': cred_diff,
            'certificates': cert_diff,
            'keys': key_diff,
            'binary_protections': bp_diff,
            'misconfigurations': misconfig_diff,
        }
        j = json.dumps(all_diffs, indent=4)
        output.write(j)
        print(f"Output diff to {output.name}")

    else:
        print(f"difference between '{asset_id_a}' and '{asset_id_b}':")

        if vuln_diff != {}:
            print(f"asset a vulnerabilities: {len(vuln_diff['a']['all'])} ({len(vuln_diff['a']['all']) - len(vuln_diff['b']['all']):+}) ({len(vuln_diff['a']['unique'])} unique)")
            print(f"asset b vulnerabilities: {len(vuln_diff['b']['all'])} ({len(vuln_diff['b']['all']) - len(vuln_diff['a']['all']):+}) ({len(vuln_diff['b']['unique'])} unique)")
            print(f"shared vulnerabilities: {len(vuln_diff['shared']['all'])}")
            print()
        if comp_diff != {}:
            print(f"asset a components: {len(comp_diff['a']['all'])} ({len(comp_diff['a']['all']) - len(comp_diff['b']['all']):+}) ({len(comp_diff['a']['unique'])} unique)")
            print(f"asset b components: {len(comp_diff['b']['all'])} ({len(comp_diff['b']['all']) - len(comp_diff['a']['all']):+}) ({len(comp_diff['b']['unique'])} unique)")
            print(f"shared components: {len(comp_diff['shared']['all'])} ({len(comp_diff['shared']['matching_version'])} of matching version)")
            print()
        if cred_diff != {}:
            print(f"asset a credentials: {len(cred_diff['a']['all'])} ({len(cred_diff['a']['all']) - len(cred_diff['b']['all']):+}) ({len(cred_diff['a']['unique'])} unique) ({len(cred_diff['a']['cracked'])} cracked)")
            print(f"asset b credentials: {len(cred_diff['b']['all'])} ({len(cred_diff['b']['all']) - len(cred_diff['a']['all']):+}) ({len(cred_diff['b']['unique'])} unique) ({len(cred_diff['b']['cracked'])} cracked)")
            print(f"shared credentials: {len(cred_diff['shared']['all'])} ({len(cred_diff['shared']['cracked'])} cracked)")
            print()
        if cert_diff != {}:
            print(f"asset a certificates: {len(cert_diff['a']['all'])} ({len(cert_diff['a']['all']) - len(cert_diff['b']['all']):+}) ({len(cert_diff['a']['unique'])} unique) ({len(cert_diff['a']['invalid'])} invalid)")
            print(f"asset b certificates: {len(cert_diff['b']['all'])} ({len(cert_diff['b']['all']) - len(cert_diff['a']['all']):+}) ({len(cert_diff['b']['unique'])} unique) ({len(cert_diff['b']['invalid'])} invalid)")
            print(f"shared certificates: {len(cert_diff['shared']['all'])} ({len(cert_diff['shared']['invalid'])} invalid)")
            print()
        if key_diff != {}:
            print(f"asset a public keys: {len(key_diff['a']['all'])} ({len(key_diff['a']['all']) - len(key_diff['b']['all']):+}) ({len(key_diff['a']['unique'])} unique) ({len(key_diff['a']['with_private'])} w/ private keys)")
            print(f"asset b public keys: {len(key_diff['b']['all'])} ({len(key_diff['b']['all']) - len(key_diff['b']['all']):+}) ({len(key_diff['b']['unique'])} unique) ({len(key_diff['b']['with_private'])} w/ private keys)")
            print(f"shared public keys: {len(key_diff['shared']['all'])} ({len(key_diff['shared']['with_private'])} w/ private keys)")
            print()
        if bp_diff != {}:
            print(f"asset a binaries: {len(bp_diff['a']['all'])} ({len(bp_diff['a']['all']) - len(bp_diff['b']['all']):+}) ({len(bp_diff['a']['unique'])} unique)")
            print(f"asset a binary protections: {int(bp_diff['a']['enabled'] / (len(bp_diff['a']['all']) * 4) * 100)}% enabled ({bp_diff['a']['enabled']}/{len(bp_diff['a']['all'])*4})")
            print(f"asset b binaries: {len(bp_diff['b']['all'])} ({len(bp_diff['b']['all']) - len(bp_diff['a']['all']):+}) ({len(bp_diff['b']['unique'])} unique)")
            print(f"asset b binary protections: {int(bp_diff['b']['enabled'] / (len(bp_diff['b']['all']) * 4) * 100)}% enabled ({bp_diff['b']['enabled']}/{len(bp_diff['b']['all'])*4})")
            print(f"shared binaries: {len(bp_diff['shared']['all'])}")
            print()
        if misconfig_diff != {}:
            print(f"asset a misconfigurations: {len(misconfig_diff['a']['failed'])} ({len(misconfig_diff['a']['unique'])} unique)")
            print(f"asset b misconfigurations: {len(misconfig_diff['b']['failed'])} ({len(misconfig_diff['b']['unique'])} unique)")
            print(f"shared misconfigurations: {len(misconfig_diff['shared']['failed'])}")
            
            # print(f"asset a misconfigurations: {len(misconfig_diff['a']['all'])} ({len(misconfig_diff['a']['all']) - len(misconfig_diff['b']['all']):+}) ({len(misconfig_diff['a']['unique'])} unique) ({len(misconfig_diff['a']['failed'])} failed)")
            # print(f"asset b misconfigurations: {len(misconfig_diff['b']['all'])} ({len(misconfig_diff['b']['all']) - len(misconfig_diff['a']['all']):+}) ({len(misconfig_diff['b']['unique'])} unique) ({len(misconfig_diff['b']['failed'])} failed)")
            # print(f"shared misconfigurations: {len(misconfig_diff['shared']['all'])} ({len(misconfig_diff['shared']['failed'])} failed)")

