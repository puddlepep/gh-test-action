import os
import yaml
import jwt
import requests
import sys
import time
from enum import Enum
from gql import Client, gql
from gql.transport.aiohttp import AIOHTTPTransport
from pydantic import BaseModel
from typing import Optional
from datetime import datetime, timedelta
from typing import TypeVar, Dict
from importlib.metadata import version


class Status(Enum):
    """
    Status of an analysis.
    """

    FAIL = "FAIL"
    INPROGRESS = "INPROGRESS"
    SUCCESS = "SUCCESS"


class Config(BaseModel):
    """Client configuration"""

    """ Endpoint to netrise autentication service with token path
    """
    token_url: str
    """ Auth0 client secret key
    """
    client_secret: str
    """ Intended recipients of the access token
    """
    audience: str
    """ Auth0 client id
    """
    client_id: str
    """ Netrise organization id
    """
    organization_id: str
    """ Netrise API endpoint
    """
    endpoint: str
    """ Submit timeout
    """
    enable_ssl: bool = True
    """ Verify SSL certificates
    """
    timeout: int = 120
    """ GQL execution timeout
    """


class Token(BaseModel):
    """Token info"""

    access_token: str
    scope: str
    expires_in: datetime
    token_type: str
    claims: dict


class SubmitInput(BaseModel):
    """Arguments for submitting a component"""

    name: str
    model: str = ""
    version: str = ""
    manufacturer: str = ""
    type: Optional[str] = None
    sbomVersion: Optional[str] = None
    assetGroupIds: Optional[list] = None


T = TypeVar("T", bound="API")


class API(Client):
    """`netrise.API` wraps gql.Client with an authentication header and exposes supporting methods
    for submitting components for analysis.
    """

    def __init__(self, config: Config, api_version: str = "v3"):
        requests.packages.urllib3.disable_warnings()  # disable warnings for when ssl is disabled

        self.api_version = api_version
        self.token = self._get_token(config)
        self.claims = jwt.decode(self.token.access_token, algorithms=["RS256"], options={"verify_signature": False})
        self.config = config

        reqHeaders = {
            "Authorization": "Bearer " + self.token.access_token,
            "apollographql-client-name": self.org,
            "apollographql-client-version": version("netrise"),
        }
        super().__init__(
            transport=AIOHTTPTransport(
                url=f"{config.endpoint}/graphql/{api_version}",
                headers=reqHeaders,
                ssl=config.enable_ssl,
                client_session_args={"trust_env": True},
            ),
            fetch_schema_from_transport=True,
            execute_timeout=config.timeout,
        )

    @staticmethod
    def _get_token(config: Config):
        """Get a client credential JWT from the Netrise authentication service"""
        payload = (
            "grant_type=client_credentials&client_id="
            + config.client_id
            + "&client_secret="
            + config.client_secret
            + "&audience="
            + config.audience
            + "&organization="
            + config.organization_id
        )
        headers = {"content-type": "application/x-www-form-urlencoded"}
        now = datetime.now()
        resp = requests.post(
            config.token_url,
            data=payload,
            headers=headers,
            verify=config.enable_ssl,
        )
        resp.raise_for_status()
        data = resp.json()
        expires_in = now + timedelta(seconds=data["expires_in"])
        access_token = data["access_token"]
        claims = jwt.decode(access_token, algorithms=["RS256"], options={"verify_signature": False})
        return Token(
            access_token=access_token,
            scope=data["scope"],
            token_type=data["token_type"],
            expires_in=expires_in,
            claims=claims,
        )

    # wrapper around Client.execute which converts all instances of %7C to
    # the correct | symbol
    def execute(self, *args, **kwargs):
        variable_values = kwargs.get("variable_values") or args[1]

        # search through variable arguments and find every asset id
        # to perform the replacement on
        keys = ["componentId", "assetId", "guid"]
        search = [variable_values]
        while len(search) > 0:
            dictionary = search.pop()
            for k, v in dictionary.items():
                if isinstance(v, dict):
                    search.append(v)
                elif k in keys:
                    dictionary[k] = v.replace("%7C", "|")

        if "variable_values" not in kwargs:
            args = list(args)
            args.pop(1)
            args = tuple(args)
        kwargs["variable_values"] = variable_values

        return super().execute(*args, **kwargs)

    # helper function which automatically collects all nodes in a paginated query
    def collect(self, query, variable_values=None, page_size=50):
        """Automatically collect all nodes in a paginated query.
        Requires the 'endCursor' and 'hasNextPage' fields to be in the given query.

        'page_size' is the amount of nodes that get processed in each query,
        increasing this can drastically speed up the amount of time this
        function takes, but it might break some queries."""

        if variable_values is None:
            variable_values = {"args": {}}

        nodes = []
        cursor = {"first": page_size}
        has_next_page = True
        while has_next_page:

            # get next page's data
            variable_values["args"]["cursor"] = cursor
            new_data = self.execute(query, variable_values)
            new_data = new_data[list(new_data.keys())[0]]

            # add the new nodes to the 'nodes' list,
            # then prepare to query for the next page
            nodes.extend([x["node"] for x in new_data["edges"]])
            cursor["after"] = new_data["pageInfo"]["endCursor"]
            has_next_page = new_data["pageInfo"]["hasNextPage"]
        return nodes

    def download_sbom(
        self,
        asset_id: str,
        sbom_type: str,
        output_file: str,
        fidelity: bool = False,
        knownUnknowns: bool = False,
        vulnerabilities: bool = False,
        vexAnalysis: bool = False,
    ):
        """Download the SBOM for a given Asset ID to the specified output_file.

        Set output_file to "" to return the text content of the SBOM instead of outputting it into a file.

        Set sbom_type to "CDX_JSON" to retrieve the SBOM in CycloneDX JSON format; "CDX_XML" for CycloneDX XML; "SPDX_JSON" for SPDX JSON; "SPDX_TAG" for SPDX Tag

        All optional SBOM toggles are disabled by default but can be enabled by setting any of the following arguments to TRUE: fidelity, knownUnknowns, vulnerabilities, vexAnalysis
        """
        reqHeaders = {
            "Authorization": "Bearer " + self.token.access_token,
            "apollographql-client-name": self.org,
            "apollographql-client-version": version("netrise"),
        }

        if sbom_type == "CDX_JSON":
            sbom_format = "FORMAT_JSON"
            sbom_specification = "VERSION_V1_4"
        elif sbom_type == "CDX_XML":
            sbom_format = "FORMAT_XML"
            sbom_specification = "VERSION_V1_4"
        elif sbom_type == "SPDX_JSON":
            sbom_format = "FORMAT_JSON"
            sbom_specification = "VERSION_V2_3"
        elif sbom_type == "SPDX_TAG":
            sbom_format = "FORMAT_TAG"
            sbom_specification = "VERSION_V2_3"
        else:
            raise ValueError(
                "sbom_type must be one of: CDX_JSON, CDX_XML, SPDX_JSON, SPDX_TAG"
            )

        asset_id = asset_id.replace("%7C", "|")
        request_body = {
            "componentId": asset_id,
            "format": sbom_format,
            "specification": sbom_specification,
            "fidelity": fidelity,
            "knownUnknowns": knownUnknowns,
            "vexAnalysis": vexAnalysis,
            "vulnerabilities": vulnerabilities,
        }

        download_sbom_response = requests.post(
            f"{self.config.endpoint}/download-sbom",
            headers=reqHeaders,
            json=request_body,
        )

        download_sbom_response.raise_for_status()

        # if no output file specified, just return the text itself
        if output_file == "":
            return download_sbom_response.content.decode("utf-8")
        else:
            with open(output_file, "wb") as f_out:
                f_out.write(download_sbom_response.content)
            return True

    def status(self, asset_id: str) -> Status:
        """Get the status of an analysis job. Use this method to check if an analysis is complete and ready
        for retrieval in `asset` or `assets` queries.

        The `asset_id` argument is the ID of the asset being analyzed.

        Returns the status of a job.
        """
        resp = self.execute(
            gql(
                """
                query GetJobStatus($args: AssetInput) {
                    asset(args: $args) {
                        status
                    }
                }
                """
            ),
            variable_values={
                "args": {"assetId": asset_id.replace("%7C", "|")}
            },
        )
        return Status(resp["asset"]["status"])

    def submit(
        self, path: str, args: SubmitInput, return_asset_id: bool = True
    ) -> str:
        """Submit a local component file for analysis.

        The `return_asset_id` argument determines whether to return the submitted component's asset id or its operation id.
        Setting this to be False can be significantly faster.

        This helper method wraps calls to request a signed URL to upload the file along with creation of the component
        record for triggering analysis.
        """

        submit_response = self.execute(
            gql(
                """
                mutation SubmitAsset($fileName: String!, $args: SubmitAssetInput) {
                    asset {
                        submit(fileName: $fileName, args: $args) {
                            uploadUrl
                            uploadId
                        }
                    }
                }
                """
            ),
            variable_values={
                "fileName": os.path.basename(path),
                "args": args.dict(),
            },
        )
        upload_response = requests.put(
            submit_response["asset"]["submit"]["uploadUrl"],
            data=open(path, "rb").read(),
            verify=self.config.enable_ssl,
        )
        upload_response.raise_for_status()

        if return_asset_id:
            poll_query = gql(
                """
                query AssetUpload($args: AssetUploadInput) {
                    assetUpload(args: $args) {
                        uploadId
                        assetId
                        uploaded
                    }
                }
                """
            )

            asset_id = ""
            uploaded = False
            while not uploaded:
                time.sleep(2)
                poll_response = self.execute(
                    poll_query,
                    variable_values={
                        "args": {
                            "uploadId": submit_response["asset"]["submit"][
                                "uploadId"
                            ]
                        }
                    },
                )
                uploaded = poll_response["assetUpload"]["uploaded"]
                asset_id = poll_response["assetUpload"]["assetId"]

            return asset_id
        else:
            return submit_response["asset"]["submit"]["uploadId"]

    def get_asset_group_id(self, group_name: str) -> str:
        """Finds an asset group by name and returns its ID.

        Returns an empty string if no asset group was found.
        """

        query = gql(
            """
            query ListAssetGroups($args: AssetGroupsInput!) {
                assetGroups(args: $args) {
                    edges {
                        node {
                            id
                            name
                        }
                    }
                    pageInfo {
                        endCursor
                        hasNextPage
                    }
                }
            }
            """
        )
        groups = self.collect(query)

        for group in groups:
            if group["name"] == group_name:
                return group["id"]
        return ""
        
    def create_asset_group(self, group_name: str, group_description: str = "", asset_ids: list = []) -> str:
        """Creates an asset group and returns its ID.

        `asset_ids` is an optional list of asset IDs which will be added to the group.
        """ 
        
        query = gql(
            """
            mutation CreateAssetGroup($args: CreateAssetGroupInput!) {
                createAssetGroup(args: $args) {
                    result
                    assetGroup { id }
                }
            }
            """
        )
        response = self.execute(
            query,
            {"args": {
                "name": group_name,
                "description": group_description,
                "assetIds": asset_ids
            }}
        )["createAssetGroup"]

        id = response["assetGroup"]["id"]
        if response["result"] == "ASSET_GROUP_RESULT_NAME_EXISTS":
            self.add_assets_to_group(id, asset_ids)
        return id

    def delete_asset_group(self, group_id: str) -> bool:
        """Deletes an asset group given its ID.

        Returns `True` if it was successfully deleted.
        """

        query = gql(
            """
            mutation DeleteAssetGroup($args: DeleteAssetGroupInput!) {
                deleteAssetGroup(args: $args)
            }
            """
        )
        return self.execute(
            query,
            {"args": {
                "id": group_id
            }}
        )["deleteAssetGroup"]
    
    def add_assets_to_group(self, group_id: str, asset_ids: list) -> bool:
        """Adds assets to an asset group.

        Returns `True` if they were successfully added.
        """

        query = gql(
            """
            mutation AddAssetsToAssetGroup($args: AddAssetsToAssetGroupInput!) {
                addAssetsToAssetGroup(args: $args)
            }
            """
        )
        return self.execute(
            query,
            {"args": {
                "id": group_id,
                "assetIds": asset_ids
            }}
        )["addAssetsToAssetGroup"]

    def remove_assets_from_group(self, group_id: str, asset_ids: list) -> bool:
        """Removes assets from an asset group.

        Returns `True` if they were successfully removed.
        """

        query = gql(
            """
            mutation RemoveAssetsFromAssetGroup($args: RemoveAssetsFromAssetGroupInput!) {
                removeAssetsFromAssetGroup(args: $args)
            }
            """
        )
        return self.execute(
            query,
            {"args": {
                "id": group_id,
                "assetIds": asset_ids
            }}
        )["removeAssetsFromAssetGroup"]
    
    def get_assets_in_group(self, group_id: str) -> list:
        """Returns all asset IDs present in a group."""

        query = gql(
            """
            query GetAssetsInGroup($args: AssetsRelayInput!) {
                assetsRelay(args: $args) {
                    edges {
                        node {
                            id
                        }
                    }
                    pageInfo {
                        hasNextPage
                        endCursor
                    }
                }
            }
            """
        )
        response = self.collect(
            query,
            {"args": {
                "groupIds": [group_id]
            }}
        )

        return [asset["id"] for asset in response]
    
    @classmethod
    def from_config_file(cls, path: str, api_version: str = "v3") -> T:
        """Initialize a `netrise.API` instance from a yaml config file."""
        with open(path, "r") as f:
            data = yaml.safe_load(f)

        try:
            client = cls(Config(**data), api_version)          
            return client
        except Exception as e:
            raise Exception("Invalid config file") from e

    @property
    def org(self):
        """Organization name authenticated to client"""
        return self.token.claims["https://netrise.io/org"]

    @property
    def org_id(self):
        """Organization id authenticated to client"""
        return self.token.claims["https://netrise.io/org_id"]

    @property
    def user(self):
        """User authenticated to client"""
        return self.token.claims["sub"]
