from .api import API


def main():
    client = API.from_config_file("config.yaml")
    print(client.current_user())
